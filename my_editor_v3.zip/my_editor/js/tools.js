
export const TOOL_LINE = 'line';
export const TOOL_RECTANGLE = 'rectangle';
export const TOOL_CIRCLE = 'circle';
export const TOOL_TRIANGLE = 'triangle';
export const TOOL_PAINT_BUCKET = 'paint_bucket';
export const TOOL_PENCIL = 'pencil';
export const TOOL_BRUSH = 'paint_brush';
export const TOOL_ERASER = 'eraser';
