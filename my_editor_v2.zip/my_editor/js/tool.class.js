export default class Tool {
    static TOOL_LINE = 'line';
    static TOOL_RECTANGLE = 'rectangle';
    static TOOL_CIRCLE = 'circle';
    static TOOL_TRIANGLE = 'triangle';
    static TOOL_PAINT_BUCKET = 'paint_bucket';
    static TOOL_PENCIL = 'pencil';
    static TOOL_BRUSH = 'paint_brush';
    static TOOL_ERASER = 'eraser';
}